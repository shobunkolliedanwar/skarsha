-- =========================================================
-- SKARSHA — Migrasi Batas Klik Gratis
-- Jalankan SETELAH migration_premium.sql (nambah kolom ke tabel users
-- yang sudah ada, aman dijalankan berkali-kali).
-- =========================================================

alter table users
  add column if not exists free_link_opens integer not null default 0;
